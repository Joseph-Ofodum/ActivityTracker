package com.decagon.Week8.pojos;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Article {
    private  int code;
    private  String name;
}
