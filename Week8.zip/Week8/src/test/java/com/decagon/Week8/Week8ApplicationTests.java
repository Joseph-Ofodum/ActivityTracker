package com.decagon.Week8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
